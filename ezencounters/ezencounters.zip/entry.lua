local package_prefix = "keristero"
local package_name = "ezencounters"

local mob_package_id = "com."..package_prefix..".mob."..package_name
local loaded_obstacles = {}
local ramdomize_test_scenario = include('random_scenario.lua')

local encounter_info = {
    enemy_packages = {
        Boomer="com.louise.enemy.Boomer",
		Gloomer="com.louise.enemy.Gloomer",
		Doomer="com.louise.enemy.Doomer",
		BurnerMan="com.OFC.char.EXE4-038-BurnerMan0",
        Cannodumb="com.OFC.char.EXEPoN-002-Cannodumb",
		Chuuton="com.OFC.char.EXEPoN-006-Chuuton",
		CirKiller="com.OFC.char.EXE4-016-CirKiller",
		BombCorn="com.louise.enemy.Corn.BombCorn",
		GigaCorn="com.louise.enemy.Corn.GigaCorn",
		MegaCorn="com.louise.enemy.Corn.MegaCorn",
		Curze="com.OFC.char.EXEPoN-016-Curze",
		Curzed="com.OFC.char.EXEPoN-016-Curzed",
		Curzena="com.OFC.char.EXEPoN-016-Curzena",
		Dharma="com.OFC.char.EXEPoN-011-Dharma",
		Dharga="com.OFC.char.EXEPoN-011-Dharga",
		Dhardara="com.OFC.char.EXEPoN-011-Dhardara",
		Ebiron="com.OFC.char.EXEPoN-005-Ebiron",
		Ebidel="com.OFC.char.EXEPoN-005-Ebidel",
		EbiSide="com.OFC.char.EXEPoN-005-EbiSide",
		Fancar="com.OFC.char.EXE1-023-Fancar",
		Fishy="com.louise.enemy.Fishy",
		Garue="com.OFC.char.EXEPoN-004-Garue",
		Garuebar="com.OFC.char.EXEPoN-004-Garuebar",
		Garuedan="com.OFC.char.EXEPoN-004-Garuedan",
		Gunner="com.OFC.char.EXE6-023-Gunner",
		HardBolz="com.OFC.char.EXEPoN-009-HardBolz",
		ColdBolz="com.OFC.char.EXEPoN-009-ColdBolz",
		MagraBolz="com.OFC.char.EXEPoN-009-MagraBolz",
		HauntedCandle="com.louise.enemy.HauntedCandle",
		HeelNavi="com.louise.enemy.HeelNavi",
		Kabutank="com.OFC.char.EXEPoN-007-Kabutank",
		Kakajee="com.OFC.char.EXE6-017-Kakajee",
		KillerEye="com.louise.enemy.KillerEye",
		DemonEye="com.louise.enemy.DemonEye",
		JokerEye="com.louise.enemy.JokerEye",
		KillPlant="com.OFC.char.EXEPoN-010-KillPlant",
		KillWeed="com.OFC.char.EXEPoN-010-KillWeed",
		KillFlower="com.OFC.char.EXEPoN-010-KillFlower",
		Kuumoss="com.OFC.char.EXE4-014-Kuumoss",
		Lark="com.louise.enemy.Lark",
		Bark="com.louise.enemy.Bark",
		Tark="com.louise.enemy.Tark",
		Metall="com.OFC.char.EXE6-001-Metall",
		MetFire="com.louise.enemy.MetFire",
		FulFire="com.louise.enemy.FulFire",
		DthFire="com.louise.enemy.DthFire",
		Metrid="com.EXE3.Metrid.Enemy",
		Piranha="com.louise.enemy.Piranha",
		Puffy="com.louise.enemy.Puffy",
		Quaker="com.louise.enemy.Quaker",
		Shaker="com.louise.enemy.Shaker",
		Breaker="com.louise.enemy.Breaker",
		Rabiri="com.OFC.char.EXEPoN-008-Rabiri",
		HighRabiri="com.OFC.char.EXEPoN-008-HighRabiri",
		MegaRabiri="com.OFC.char.EXEPoN-008-MegaRabiri",
		StarMan="com.OFC.char.EXE45-036-StarMan1",
		Swordy="mob.realms.rey.virus.009.swordy",
		Volgear="com.louise.char.Volgear",
		WindBox="com.louise.enemy.WindBox",
		VacuumFan="com.louise.enemy.VacuumFan",
		Yort="mob.realms.rey.virus.039.yort",
		Yura="com.OFC.char.EXEPoN-014-Yura",
		Yurayura="com.OFC.char.EXEPoN-014-Yurayura",
		Yurarion="com.OFC.char.EXEPoN-014-Yurarion",
		GutsMan="com.Thor.enemy.Gutsman_V1",
    },
    obstacles = {
        RockCube="obstacles/rock_cube.lua",
        Rock="obstacles/rock.lua",
        Coffin="obstacles/coffin.lua",
        BlastCube="obstacles/blast_cube.lua",
        IceCube="obstacles/ice_cube.lua",
        MysteryData="obstacles/mystery.lua",
    },
    tile_states = {
        0,--normal
        1,--cracked
        2,--broken
        11,--up
        12,--down
        9,--left
        10,--right
        7,--empty
        4,--grass
        17,--hidden
        8,--holy
        3,--ice
        5,--lava
        6,--poison
        13,--volcano
        14,--sea
        15,--sand
        16,--metal
    },
    enemy_ranks = {
        0,--v1
        1,--v2
        2,--v3
        3,--sp
        4,--ex
        5,--rare1
        6,--rare2
        7--nightmare
    },
    field_tiles_default = {
        {1,1,1,1,1,1},
        {1,1,1,1,1,1},
        {1,1,1,1,1,1}
    },
    field_teams_default = {
        {2,2,2,1,1,1},
        {2,2,2,1,1,1},
        {2,2,2,1,1,1}
    }
}

function get_enum_value_by_index(mapping_table,p_index)
    for i, value in ipairs(mapping_table) do
        if tonumber(i) == tonumber(p_index) then
            return value
        end
    end
    print("[ezencounters] WARNING invalid input data, no index",p_index)
end

function resolve_enemy_rank(rank_token)
    if rank_token == nil then
        print("[ezencounters] WARNING missing rank token")
        return nil
    end

    local numeric_index = tonumber(rank_token)
    if numeric_index ~= nil then
        return get_enum_value_by_index(encounter_info.enemy_ranks, numeric_index)
    end

    local token = tostring(rank_token)

    if token == "sp" or token == "SP" then
        return get_enum_value_by_index(encounter_info.enemy_ranks, 4)
    elseif token == "rare1" or token == "Rare1" then
        return get_enum_value_by_index(encounter_info.enemy_ranks, 6)
    elseif token == "rare2" or token == "Rare2" then
        return get_enum_value_by_index(encounter_info.enemy_ranks, 7)
    elseif token == "nm" or token == "NM" then
        return get_enum_value_by_index(encounter_info.enemy_ranks, 8)
    end

    print("[ezencounters] WARNING invalid rank token", rank_token)
    return nil
end

function package_requires_scripts()
    for mob_alias, package in pairs(encounter_info.enemy_packages) do
        --print('[ezencounters] requiring '..package)
        Engine.requires_character(package)
    end
end

function get_package_id(alias) 
    return encounter_info.enemy_packages[alias]
end

function package_init(package) 
    package:declare_package_id(mob_package_id)
    package:set_name(package_name)
    package:set_description("Initiate custom battles from the server!")
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob,data) 
    --First a work around to not crash the server, include the obstacle scripts here rather than in global scope
    for obstacle_alias, script_path in pairs(encounter_info.obstacles) do
        --print('[ezencounters] including '..script_path)
        loaded_obstacles[obstacle_alias] = include(script_path)
    end
    --work around end

    --TESTING, uncomment to set up custom arrangements of enemies for testing
    --[[local data = {
        enemies = {
            {name="Mettaur",rank=1},
        },
        positions = {
            {0,0,0,0,0,1},
            {0,0,0,0,1,0},
            {0,0,0,1,0,0}
        },
    }]]
    --

    local field = mob:get_field()
    --can setup music, and field here
    if not data then
        --test data here
        local flip_field = false
        data = ramdomize_test_scenario(encounter_info,flip_field)
    end
    --print('building package with data!')
    --load tile states from  data
    if not data.tiles then
        data.tiles = encounter_info.field_tiles_default
    end
    for y, x_table in ipairs(data.tiles) do
        for x, tile_state_index in ipairs(x_table) do
            local tile = field:tile_at(x,y)
            local tile_state = get_enum_value_by_index(encounter_info.tile_states,tile_state_index)
            tile:set_state(tile_state)
        end
    end

    --load tile teams from  data
    if not data.teams then
        data.teams = encounter_info.field_teams_default
    end
    for y, x_table in ipairs(data.teams) do
        for x, team_index in ipairs(x_table) do
            local tile = field:tile_at(x,y)
            tile:set_team(team_index,false)
        end
    end

    --load enemies from data
    if not data.enemies then
        print('[ezencounters] WARNING no enemies listed for encounter')
        return
    end
    spawners = {}
    for index, enemy_info in ipairs(data.enemies) do
        local enemy_rank = resolve_enemy_rank(enemy_info.rank)
        if enemy_rank == nil then
            print(
                "[ezencounters] WARNING unresolved rank token, defaulting to 1",
                "alias=", tostring(enemy_info.name),
                "rank_token=", tostring(enemy_info.rank)
            )
            enemy_rank = get_enum_value_by_index(encounter_info.enemy_ranks, 1)
        end
        local package_id = get_package_id(enemy_info.name)
        if not package_id then
            print(
                "[ezencounters] ERROR unknown enemy alias",
                "idx=", index,
                "alias=", tostring(enemy_info.name)
            )
        end

        print(
            "[ezencounters] spawn attempt",
            "idx=", index,
            "alias=", tostring(enemy_info.name),
            "rank_index=", tostring(enemy_info.rank),
            "resolved_rank=", tostring(enemy_rank),
            "package_id=", tostring(package_id)
        )

        local ok, result = pcall(function()
            return mob:create_spawner(package_id, enemy_rank)
        end)

        if not ok then
            print(
                "[ezencounters] ERROR create_spawner failed",
                "idx=", index,
                "alias=", tostring(enemy_info.name),
                "rank_index=", tostring(enemy_info.rank),
                "resolved_rank=", tostring(enemy_rank),
                "package_id=", tostring(package_id),
                "error=", tostring(result)
            )

            -- mark the spawner slot as missing so we can log positions later too
            spawners[index] = nil
        else
            spawners[index] = result
        end
    end

    --spawn enemies at positions
    if not data.positions then
        print('[ezencounters] WARNING no enemy spawn positions')
        return
    end
    for y, x_table in ipairs(data.positions) do
        for x, spawner_id in ipairs(x_table) do
            if spawner_id ~= 0 then
                local spawner = spawners[spawner_id]
                local enemy_info = data.enemies[spawner_id]

                if not spawner then
                    print(
                        "[ezencounters] ERROR missing spawner at position",
                        "x=", x,
                        "y=", y,
                        "spawner_id=", tostring(spawner_id),
                        "alias=", tostring(enemy_info and enemy_info.name),
                        "rank_index=", tostring(enemy_info and enemy_info.rank)
                    )
                else
                    local mutator = spawner:spawn_at(x, y)
                    mutator:mutate(function (character)
                        if enemy_info.nickname ~= nil then
                            character:set_name(enemy_info.nickname)
                        end
                        if enemy_info.max_hp ~= nil then
                            --character:mod_max_hp(enemy_info.max_hp) it dont work
                        end
                        if enemy_info.starting_hp ~= nil then
                            character:set_health(enemy_info.starting_hp)
                        end
                    end)
                end
            end
        end
    end

    if data.player_positions then
        for y, x_table in ipairs(data.player_positions) do
            for x, player_id in ipairs(x_table) do
                if player_id ~= 0 then
                    mob:spawn_player( player_id, x, y )
                end
            end
        end
    end

    if data.freedom_mission then
        local turns = 3
        local can_flip = true
        if data.freedom_mission.turns ~= nil then
            turns = data.freedom_mission.turns
        end
        if data.freedom_mission.player_can_flip ~= nil then
            can_flip = data.freedom_mission.player_can_flip
        end
        mob:enable_freedom_mission(turns,can_flip)
    end

    if data.music then
        local loop_start = 0
        local loop_end = 0
        if data.music.loop_start then
            loop_start = data.music.loop_start
        end
        if data.music.loop_end then
            loop_end = data.music.loop_end
        end
        mob:stream_music(_folderpath.."/music/"..data.music.path,loop_start,loop_end)
    end

    if data.obstacle_positions then
        for y, x_table in ipairs(data.obstacle_positions) do
            for x, obstacle_id in ipairs(x_table) do
                if obstacle_id ~= 0 then
                    local obstacle_info = data.obstacles[obstacle_id]
                    local create_obstacle_func = loaded_obstacles[obstacle_info.name]
                    local new_obstacle = create_obstacle_func()
                    --print('spawning obstacle '..obstacle_info.name..' at '..x..','..y)
                    field:spawn(new_obstacle,x,y)
                end
            end
        end
    end

end